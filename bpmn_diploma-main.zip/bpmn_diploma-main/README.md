# npm install or yarn install 

# npm run dev sss