import translate from './translate';
export default translate;
