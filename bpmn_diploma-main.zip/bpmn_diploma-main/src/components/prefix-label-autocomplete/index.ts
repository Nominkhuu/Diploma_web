import PrefixAutoComplete from './PrefixAutoComplete';

export default PrefixAutoComplete;
