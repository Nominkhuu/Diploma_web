import Pannel from './Panel';
export default Pannel;
