import PrefixLabelSelect from './PrefixLabelSelect';

export default PrefixLabelSelect;
