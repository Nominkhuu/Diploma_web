declare const React: string;
declare module '*.json';
declare module '*.png';
declare module '*.jpg';
declare module '*.bpmn';
