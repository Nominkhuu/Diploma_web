declare module 'bpmn-js' {
  const Viewer: any;
  export default Viewer;
}

declare module 'bpmn-js/lib/Modeler' {
  const Modeler: any;
  export default Modeler;
}
